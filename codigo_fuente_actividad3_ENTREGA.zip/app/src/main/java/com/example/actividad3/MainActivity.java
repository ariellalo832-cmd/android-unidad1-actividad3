package com.example.actividad3;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Random;

public class MainActivity extends Activity {
    private static final String TAG = "Actividad3";
    private static final int N = 1_000_000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView resultado = findViewById(R.id.resultado);
        resultado.setText("Procesando un millon de enteros...");

        // Se procesa fuera del hilo principal para no congelar la interfaz.
        new Thread(() -> {
            long inicioTotal = SystemClock.elapsedRealtimeNanos();
            int[] numeros = new int[N];
            Random aleatorio = new Random(20261120L);
            for (int i = 0; i < N; i++) {
                numeros[i] = aleatorio.nextInt(1_000_000);
            }

            long inicioOrdenamiento = SystemClock.elapsedRealtimeNanos();
            Arrays.sort(numeros);
            long fin = SystemClock.elapsedRealtimeNanos();

            double tiempoOrdenarMs = (fin - inicioOrdenamiento) / 1_000_000.0;
            double tiempoTotalMs = (fin - inicioTotal) / 1_000_000.0;
            boolean ordenado = true;
            for (int i = 1; i < N; i++) {
                if (numeros[i - 1] > numeros[i]) {
                    ordenado = false;
                    break;
                }
            }
            String resumen = "Elementos: " + N
                    + " | ordenado: " + ordenado
                    + " | minimo: " + numeros[0]
                    + " | maximo: " + numeros[N - 1]
                    + " | ordenar: " + tiempoOrdenarMs + " ms"
                    + " | total: " + tiempoTotalMs + " ms";
            Log.i(TAG, "INICIO: prueba de ordenamiento");
            Log.i(TAG, resumen);
            Log.i(TAG, "FIN: prueba de ordenamiento");
            runOnUiThread(() -> resultado.setText(resumen));
        }).start();
    }
}
